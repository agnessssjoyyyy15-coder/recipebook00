import "dotenv/config";
import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import recipeRoutes from "./routes/recipes.js";

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "Recipe Book API" }));
app.use("/api/recipes", recipeRoutes);

app.use((req, res) => res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` }));
app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.name === "ValidationError") return res.status(400).json({ message: error.message });
  if (error.name === "MongoServerSelectionError" || error.name === "MongooseServerSelectionError") {
    return res.status(503).json({ message: "Cannot connect to MongoDB. Check MONGODB_URI and Atlas network access." });
  }
  res.status(500).json({ message: "Something went wrong on the server." });
});

mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log("Connected to MongoDB");
    app.listen(PORT, () => console.log(`Recipe Book API running on http://localhost:${PORT}`));
  })
  .catch(error => {
    console.error("MongoDB connection failed:", error.message);
    console.error("Check backend/.env and your MongoDB Atlas network access.");
    process.exit(1);
  });
