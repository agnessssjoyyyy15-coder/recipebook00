import mongoose from "mongoose";

const recipeSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, "Recipe name is required"], trim: true, maxlength: 100 },
    category: {
      type: String,
      required: [true, "Category is required"],
      enum: ["Breakfast", "Lunch", "Dinner", "Snack", "Dessert"],
    },
    ingredients: { type: [String], required: true, validate: v => v.length > 0 },
    steps: { type: [String], required: true, validate: v => v.length > 0 },
    cookingTime: { type: Number, required: true, min: [1, "Cooking time must be at least 1 minute"], max: 1440 },
  },
  { timestamps: true }
);

export default mongoose.model("Recipe", recipeSchema);
