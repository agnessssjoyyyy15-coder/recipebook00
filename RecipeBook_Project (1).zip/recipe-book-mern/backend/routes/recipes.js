import { Router } from "express";
import mongoose from "mongoose";
import Recipe from "../models/Recipe.js";

const router = Router();

function cleanLines(value) {
  if (Array.isArray(value)) return value.map(item => String(item).trim()).filter(Boolean);
  if (typeof value === "string") return value.split(/\r?\n|,/).map(item => item.trim()).filter(Boolean);
  return [];
}

function validatePayload(body) {
  const name = String(body.name ?? "").trim();
  const category = String(body.category ?? "").trim();
  const ingredients = cleanLines(body.ingredients);
  const steps = cleanLines(body.steps);
  const cookingTime = Number(body.cookingTime);
  const categories = ["Breakfast", "Lunch", "Dinner", "Snack", "Dessert"];

  if (!name) return "Recipe name is required.";
  if (!categories.includes(category)) return "Choose a valid category.";
  if (!ingredients.length) return "Enter at least one ingredient.";
  if (!steps.length) return "Enter at least one preparation step.";
  if (!Number.isInteger(cookingTime) || cookingTime < 1 || cookingTime > 1440) {
    return "Cooking time must be a whole number between 1 and 1440 minutes.";
  }
  return { name, category, ingredients, steps, cookingTime };
}

router.get("/", async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.category && req.query.category !== "All") filter.category = req.query.category;
    if (req.query.search) {
      const term = String(req.query.search).trim();
      filter.$or = [
        { name: { $regex: term, $options: "i" } },
        { ingredients: { $regex: term, $options: "i" } },
      ];
    }
    const recipes = await Recipe.find(filter).sort({ createdAt: -1 });
    res.json(recipes);
  } catch (error) { next(error); }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid recipe ID." });
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) return res.status(404).json({ message: "Recipe not found." });
    res.json(recipe);
  } catch (error) { next(error); }
});

router.post("/", async (req, res, next) => {
  try {
    const payload = validatePayload(req.body);
    if (typeof payload === "string") return res.status(400).json({ message: payload });
    const recipe = await Recipe.create(payload);
    res.status(201).json({ message: "Recipe added successfully!", recipe });
  } catch (error) { next(error); }
});

router.put("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid recipe ID." });
    const payload = validatePayload(req.body);
    if (typeof payload === "string") return res.status(400).json({ message: payload });
    const recipe = await Recipe.findByIdAndUpdate(req.params.id, payload, { new: true, runValidators: true });
    if (!recipe) return res.status(404).json({ message: "Recipe not found." });
    res.json({ message: "Recipe updated successfully!", recipe });
  } catch (error) { next(error); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid recipe ID." });
    const recipe = await Recipe.findByIdAndDelete(req.params.id);
    if (!recipe) return res.status(404).json({ message: "Recipe not found." });
    res.json({ message: "Recipe deleted successfully!" });
  } catch (error) { next(error); }
});

export default router;
