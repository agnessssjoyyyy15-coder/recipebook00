import { useCallback, useEffect, useMemo, useState } from "react";
import {
  BookOpen, ChefHat, Clock3, Search, Plus, Pencil, Trash2, X, ArrowLeft,
  Utensils, Leaf, Heart, Sparkles, ChevronRight, CookingPot
} from "lucide-react";

const API = (import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace(/\/$/, "");
const CATEGORIES = ["Breakfast", "Lunch", "Dinner", "Snack", "Dessert"];
const categoryEmoji = { Breakfast: "🥞", Lunch: "🥗", Dinner: "🍝", Snack: "🥑", Dessert: "🍰" };

const emptyForm = { name: "", category: "Breakfast", ingredients: "", steps: "", cookingTime: "" };

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed. Check that the backend is running.");
  return data;
}

function lines(value) {
  return value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
}

function RecipeForm({ recipe, onClose, onSaved }) {
  const [form, setForm] = useState(recipe ? {
    name: recipe.name, category: recipe.category,
    ingredients: recipe.ingredients.join("\n"), steps: recipe.steps.join("\n"),
    cookingTime: String(recipe.cookingTime),
  } : emptyForm);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));

  async function submit(event) {
    event.preventDefault();
    setError("");
    const ingredients = lines(form.ingredients);
    const steps = lines(form.steps);
    const cookingTime = Number(form.cookingTime);
    if (!form.name.trim() || !ingredients.length || !steps.length) {
      setError("Please fill in the name, ingredients, and preparation steps.");
      return;
    }
    if (!Number.isInteger(cookingTime) || cookingTime < 1 || cookingTime > 1440) {
      setError("Cooking time must be a whole number from 1 to 1440 minutes.");
      return;
    }
    setBusy(true);
    try {
      const payload = { name: form.name.trim(), category: form.category, ingredients, steps, cookingTime };
      const data = await request(recipe ? `/recipes/${recipe._id}` : "/recipes", {
        method: recipe ? "PUT" : "POST", body: JSON.stringify(payload),
      });
      onSaved(data.message || "Saved successfully!");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return <div className="overlay" role="presentation" onMouseDown={e => e.target === e.currentTarget && onClose()}>
    <section className="dialog form-dialog" role="dialog" aria-modal="true" aria-labelledby="form-title">
      <div className="dialog-head">
        <div><span className="eyebrow">{recipe ? "A LITTLE UPDATE" : "ADD SOMETHING DELICIOUS"}</span>
          <h2 id="form-title">{recipe ? "Edit your recipe" : "New recipe"}</h2></div>
        <button className="icon-button" onClick={onClose} aria-label="Close"><X size={20}/></button>
      </div>
      <form onSubmit={submit} className="recipe-form">
        <label>Recipe name<input autoFocus maxLength="100" placeholder="e.g. Creamy tomato pasta" value={form.name} onChange={e => update("name", e.target.value)} required /></label>
        <div className="form-row">
          <label>Category<select value={form.category} onChange={e => update("category", e.target.value)}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></label>
          <label>Cooking time (minutes)<input type="number" min="1" max="1440" step="1" placeholder="25" value={form.cookingTime} onChange={e => update("cookingTime", e.target.value)} required /></label>
        </div>
        <label>Ingredients <span className="label-hint">one per line</span><textarea rows="4" placeholder={"2 tomatoes\n1 tbsp olive oil\nSalt and pepper"} value={form.ingredients} onChange={e => update("ingredients", e.target.value)} required /></label>
        <label>Preparation steps <span className="label-hint">one step per line</span><textarea rows="4" placeholder={"Chop the vegetables.\nHeat oil in a pan.\nCook and serve warm."} value={form.steps} onChange={e => update("steps", e.target.value)} required /></label>
        {error && <p className="error-message">{error}</p>}
        <div className="form-actions"><button type="button" className="button button-quiet" onClick={onClose}>Cancel</button><button disabled={busy} className="button button-primary" type="submit">{busy ? "Saving…" : recipe ? "Save changes" : "Save recipe"}</button></div>
      </form>
    </section>
  </div>;
}

function RecipeDetails({ recipe, onClose, onEdit, onDelete }) {
  return <div className="overlay" role="presentation" onMouseDown={e => e.target === e.currentTarget && onClose()}>
    <section className="dialog details-dialog" role="dialog" aria-modal="true" aria-labelledby="detail-title">
      <div className={`detail-banner banner-${CATEGORIES.indexOf(recipe.category)}`}>
        <button className="icon-button detail-close" onClick={onClose} aria-label="Close"><X size={20}/></button>
        <span className="detail-emoji">{categoryEmoji[recipe.category] || "🍲"}</span>
        <span className="pill">{recipe.category}</span>
        <h2 id="detail-title">{recipe.name}</h2>
        <span className="time-line"><Clock3 size={16}/> {recipe.cookingTime} minutes</span>
      </div>
      <div className="detail-content">
        <div className="detail-columns">
          <section><h3><Leaf size={18}/> Ingredients <span>{recipe.ingredients.length}</span></h3>
            <ul className="ingredient-list">{recipe.ingredients.map((item, i) => <li key={i}><span className="bullet"/> {item}</li>)}</ul></section>
          <section><h3><CookingPot size={18}/> Preparation</h3>
            <ol className="step-list">{recipe.steps.map((step, i) => <li key={i}><span>{String(i + 1).padStart(2, "0")}</span><p>{step}</p></li>)}</ol></section>
        </div>
        <div className="detail-actions"><button className="button button-quiet" onClick={() => onDelete(recipe)}><Trash2 size={16}/> Delete</button><button className="button button-primary" onClick={() => onEdit(recipe)}><Pencil size={16}/> Edit recipe</button></div>
      </div>
    </section>
  </div>;
}

function RecipeCard({ recipe, onOpen, onEdit, onDelete, index }) {
  return <article className="recipe-card" style={{ "--card-index": index }}>
    <button className={`card-art art-${CATEGORIES.indexOf(recipe.category)}`} onClick={() => onOpen(recipe)} aria-label={`View ${recipe.name}`}>
      <span className="card-emoji">{categoryEmoji[recipe.category] || "🍲"}</span>
      <span className="card-category">{recipe.category}</span>
      <span className="card-open"><ChevronRight size={18}/></span>
    </button>
    <div className="card-body">
      <button className="card-title" onClick={() => onOpen(recipe)}>{recipe.name}</button>
      <div className="card-meta"><span><Clock3 size={15}/>{recipe.cookingTime} min</span><span><Utensils size={15}/>{recipe.ingredients.length} ingredients</span></div>
      <div className="card-footer"><span className="tiny-note">MADE WITH LOVE</span><div className="card-actions">
        <button className="mini-action" onClick={() => onEdit(recipe)} aria-label={`Edit ${recipe.name}`}><Pencil size={15}/></button>
        <button className="mini-action delete-action" onClick={() => onDelete(recipe)} aria-label={`Delete ${recipe.name}`}><Trash2 size={15}/></button>
      </div></div>
    </div>
  </article>;
}

export default function App() {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [modal, setModal] = useState(null);
  const [toast, setToast] = useState("");
  const [deleting, setDeleting] = useState(false);

  const loadRecipes = useCallback(async () => {
    setLoading(true);
    setLoadError("");
    try {
      const data = await request("/recipes");
      setRecipes(data);
    } catch (err) {
      setLoadError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadRecipes(); }, [loadRecipes]);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 3500);
    return () => clearTimeout(timer);
  }, [toast]);

  const visibleRecipes = useMemo(() => recipes.filter(recipe => {
    const matchesCategory = category === "All" || recipe.category === category;
    const term = search.toLowerCase().trim();
    const matchesSearch = !term || recipe.name.toLowerCase().includes(term) ||
      recipe.ingredients.some(item => item.toLowerCase().includes(term));
    return matchesCategory && matchesSearch;
  }), [recipes, search, category]);

  function saved(message) {
    setModal(null);
    setToast(message);
    loadRecipes();
  }

  function editRecipe(recipe) { setModal({ type: "form", recipe }); }
  async function deleteRecipe(recipe) {
    if (!window.confirm(`Delete "${recipe.name}"? This cannot be undone.`)) return;
    setDeleting(true);
    try {
      const data = await request(`/recipes/${recipe._id}`, { method: "DELETE" });
      setModal(null);
      setToast(data.message || "Recipe deleted.");
      await loadRecipes();
    } catch (err) { setToast(err.message); }
    finally { setDeleting(false); }
  }

  return <div className="app-shell">
    <header className="topbar"><a href="#" className="brand" onClick={e => { e.preventDefault(); setModal(null); }}><span className="brand-mark"><ChefHat size={23}/></span><span>little<span className="brand-accent">plate</span><small>YOUR PERSONAL RECIPE BOOK</small></span></a>
      <nav><a className="nav-active" href="#recipes">My recipes</a><a href="#about">Our little kitchen</a></nav>
      <button className="button button-primary top-add" onClick={() => setModal({ type: "form" })}><Plus size={17}/> Add recipe</button>
    </header>

    <main>
      <section className="hero">
        <div className="hero-copy"><span className="eyebrow"><Sparkles size={14}/> A PINCH OF LOVE, A DASH OF YOU</span>
          <h1>Good food.<br/><em>Good mood.</em></h1>
          <p>Keep your favourite recipes close, discover your next comfort meal, and make every bite a little more special.</p>
          <a href="#recipes" className="hero-link">Explore my cookbook <ArrowLeft size={16}/></a>
          <div className="hero-stats"><div><strong>{recipes.length.toString().padStart(2, "0")}</strong><span>RECIPES SAVED</span></div><i/><div><strong>∞</strong><span>WAYS TO ENJOY</span></div></div>
        </div>
        <div className="hero-visual"><div className="hero-orbit orbit-one"/><div className="hero-orbit orbit-two"/><div className="hero-food">🥘</div><div className="floating-note note-top"><Heart size={15} fill="currentColor"/> cooked with love</div><div className="floating-note note-bottom"><Clock3 size={15}/> your next favourite</div><span className="hero-spark spark-one">✳</span><span className="hero-spark spark-two">✦</span></div>
      </section>

      <section className="collection" id="recipes">
        <div className="section-heading"><div><span className="eyebrow">FROM MY KITCHEN TO YOURS</span><h2>Your collection<span>.</span></h2><p>A home for all the dishes you love.</p></div>
          <label className="search-box"><Search size={18}/><input aria-label="Search recipes" placeholder="Find a recipe…" value={search} onChange={e => setSearch(e.target.value)}/>{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={15}/></button>}</label>
        </div>
        <div className="filter-row"><div className="category-filters">{["All", ...CATEGORIES].map(c => <button key={c} className={`filter-chip ${category === c ? "selected" : ""}`} onClick={() => setCategory(c)}>{c !== "All" && <span>{categoryEmoji[c]}</span>}{c}</button>)}</div><span className="results-count">{visibleRecipes.length} {visibleRecipes.length === 1 ? "recipe" : "recipes"}</span></div>

        {loading ? <div className="state-panel"><div className="loading-dot"/> <p>Setting the table…</p></div> :
        loadError ? <div className="state-panel error-panel"><span className="state-icon">🥄</span><h3>We couldn't reach the kitchen</h3><p>{loadError}</p><button className="button button-primary" onClick={loadRecipes}>Try again</button><small>Make sure the backend is running and MongoDB is configured.</small></div> :
        visibleRecipes.length ? <div className="recipe-grid">{visibleRecipes.map((recipe, index) => <RecipeCard key={recipe._id} recipe={recipe} index={index} onOpen={r => setModal({ type: "details", recipe: r })} onEdit={editRecipe} onDelete={deleteRecipe}/>)}</div> :
        <div className="empty-state"><div className="empty-art">🍋</div><h3>{search || category !== "All" ? "No recipes found just yet" : "Your cookbook starts here"}</h3><p>{search || category !== "All" ? "Try another search or category — your next favourite might be hiding." : "Save that family favourite or your new kitchen experiment."}</p>{search || category !== "All" ? <button className="button button-quiet" onClick={() => { setSearch(""); setCategory("All"); }}>Clear filters</button> : <button className="button button-primary" onClick={() => setModal({ type: "form" })}><Plus size={17}/> Add your first recipe</button>}</div>}
      </section>

      <section className="quote-strip" id="about"><span>✳</span><p>“The secret ingredient is always a little bit of love.”</p><span>✳</span></section>
    </main>
    <footer><a href="#" className="footer-brand"><ChefHat size={19}/> little<span>plate</span></a><span>A little cookbook for a life well-seasoned.</span><span>MADE WITH <Heart size={12} fill="currentColor"/> AT HOME</span></footer>

    {modal?.type === "form" && <RecipeForm key={modal.recipe?._id || "new"} recipe={modal.recipe} onClose={() => setModal(null)} onSaved={saved}/>}
    {modal?.type === "details" && <RecipeDetails recipe={modal.recipe} onClose={() => setModal(null)} onEdit={editRecipe} onDelete={deleteRecipe}/>}
    {toast && <div className="toast" role="status"><span>✓</span>{toast}<button onClick={() => setToast("")} aria-label="Dismiss"><X size={15}/></button></div>}
    {deleting && <div className="busy-cover">Updating your cookbook…</div>}
  </div>;
}
